<?php

namespace Spatie\LaravelIgnition\ContextProviders;

use Spatie\FlareClient\Context\ConsoleContextProvider;

class LaravelConsoleContextProvider extends ConsoleContextProvider
{
}
